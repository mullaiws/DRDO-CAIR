import sys
import numpy as np
import rasterio
import matplotlib.pyplot as plt
import pandas as pd
from queue import PriorityQueue
import heapq
from PyQt5.QtWidgets import (QApplication, QMainWindow, QPushButton, QFileDialog, QVBoxLayout,
                             QWidget, QInputDialog, QTextEdit)
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas, NavigationToolbar2QT as NavigationToolbar

class DEMPathPlanner(QMainWindow):
    def __init__(self):
        super().__init__()
        self.initUI()
        self.dem_data = None
        self.slope_data = None
        self.valid_mask = None
        self.transform = None
        self.start = None
        self.goal = None
        self.min_elev = None
        self.max_elev = None
        self.go_area = None
        self.visited_nodes = set()

    def initUI(self):
        self.setWindowTitle("DEM Path Planner")
        self.setGeometry(100, 100, 1400, 900)

        self.canvas = FigureCanvas(plt.figure(figsize=(10, 6)))
        self.toolbar = NavigationToolbar(self.canvas, self)
        self.canvas.mpl_connect("button_press_event", self.mouse_click_event)

        self.btn_load = QPushButton("Load DEM + Slope", self)
        self.btn_load.clicked.connect(self.load_dem)

        self.btn_compute = QPushButton("Compute Path", self)
        self.btn_compute.clicked.connect(self.compute_path)

        self.btn_export = QPushButton("Export CSV", self)
        self.btn_export.clicked.connect(lambda: self.export_path_csv(self.reconstruct_path({}, self.goal)) if self.goal else None)

        self.status_log = QTextEdit()
        self.status_log.setReadOnly(True)

        layout = QVBoxLayout()
        layout.addWidget(self.toolbar)
        layout.addWidget(self.canvas)
        layout.addWidget(self.btn_load)
        layout.addWidget(self.btn_compute)
        layout.addWidget(self.btn_export)
        layout.addWidget(self.status_log)

        container = QWidget()
        container.setLayout(layout)
        self.setCentralWidget(container)

    def log(self, text):
        self.status_log.append(text)

    def load_dem(self):
        options = QFileDialog.Options()
        file_name, _ = QFileDialog.getOpenFileName(self, "Open DEM File", "", "GeoTIFF Files (*.tif);;All Files (*)", options=options)
        slope_file, _ = QFileDialog.getOpenFileName(self, "Open Slope File", "", "GeoTIFF Files (*.tif);;All Files (*)", options=options)

        if file_name and slope_file:
            with rasterio.open(file_name) as src:
                self.dem_data = src.read(1)
                self.transform = src.transform

            with rasterio.open(slope_file) as src:
                self.slope_data = src.read(1)

            min_elev, ok1 = QInputDialog.getDouble(self, "Elevation Input", "Enter minimum elevation for GO areas:", float(np.min(self.dem_data)))
            max_elev, ok2 = QInputDialog.getDouble(self, "Elevation Input", "Enter maximum elevation for GO areas:", float(np.max(self.dem_data)))

            if ok1 and ok2:
                self.min_elev = min_elev
                self.max_elev = max_elev
                self.go_area = (self.dem_data >= self.min_elev) & (self.dem_data <= self.max_elev)
                self.valid_mask = self.go_area & (self.slope_data <= 45)
                self.log(f"GO area pixels: {np.sum(self.go_area)} | Valid mask pixels: {np.sum(self.valid_mask)}")
                self.plot_dem()
            else:
                self.log("Elevation input canceled.")

    def plot_dem(self):
        plt.clf()
        plt.imshow(self.valid_mask, cmap='Greens')
        plt.colorbar(label='Valid Path Region')
        plt.title("DEM Map with Valid Path Mask")

        if self.start:
            plt.plot(self.start[1], self.start[0], marker='o', color='green', markersize=8, label='Start')
        if self.goal:
            plt.plot(self.goal[1], self.goal[0], marker='o', color='red', markersize=8, label='Goal')

        if self.start or self.goal:
            plt.legend()

        self.canvas.draw()

    def mouse_click_event(self, event):
        if event.xdata is None or event.ydata is None:
            return
        row, col = int(event.ydata), int(event.xdata)
        if self.go_area is not None and not self.go_area[row, col]:
            self.log("Selected point is not in GO area! Choose another location.")
            return
        if self.start is None:
            self.start = (row, col)
            self.log(f"Start set at: {self.start}")
        elif self.goal is None:
            self.goal = (row, col)
            self.log(f"Goal set at: {self.goal}")
        self.plot_dem()

    def compute_path(self):
        import time
        if self.dem_data is None or self.slope_data is None or self.start is None or self.goal is None:
            self.log("Load DEM + Slope, set elevation range, and select start/goal points first!")
            return

        start_time = time.time()
        path = self.a_star_subpixel()
        end_time = time.time()

        self.log(f"Path computation time: {end_time - start_time:.2f} sec")

        if path:
            self.plot_path(path)
            self.plot_elevation_profile(path)
            self.save_graphs()
            self.export_path_csv(path)
            self.plot_zoomed_path(path)
            self.plot_visited_nodes()
        else:
            self.log("No valid path found!")

    def a_star_subpixel(self, substeps=4, angular_resolution=32):
        rows, cols = self.dem_data.shape
        start = (self.start[0] + 0.5, self.start[1] + 0.5)
        goal = (self.goal[0] + 0.5, self.goal[1] + 0.5)

        open_set = [(0, start)]
        heapq.heapify(open_set)
        came_from = {}
        g_score = {self._quantize(start): 0}
        self.visited_nodes.clear()

        directions = [(np.cos(theta), np.sin(theta)) for theta in np.linspace(0, 2*np.pi, angular_resolution, endpoint=False)]

        def heuristic(a, b):
            return np.hypot(a[0] - b[0], a[1] - b[1])

        visited = set()

        while open_set:
            _, current = heapq.heappop(open_set)
            if heuristic(current, goal) < (2.0 / substeps):
                return self.reconstruct_path(came_from, current)

            key = self._quantize(current)
            if key in visited:
                continue
            visited.add(key)
            self.visited_nodes.add(key)

            for dx, dy in directions:
                neighbor = (current[0] + dx / substeps, current[1] + dy / substeps)
                if heuristic(neighbor, goal) >= heuristic(current, goal):
                    continue
                r, c = int(neighbor[0]), int(neighbor[1])
                if 0 <= r < rows and 0 <= c < cols and self.valid_mask[r, c]:
                    neighbor_key = self._quantize(neighbor)
                    tentative_g = g_score[key] + np.hypot(dx, dy) / substeps
                    if neighbor_key not in g_score or tentative_g < g_score[neighbor_key]:
                        came_from[neighbor] = current
                        g_score[neighbor_key] = tentative_g
                        f_score = tentative_g + heuristic(neighbor, goal)
                        heapq.heappush(open_set, (f_score, neighbor))

        return None

    def _quantize(self, point, precision=2):
        return (round(point[0], precision), round(point[1], precision))

    def reconstruct_path(self, came_from, current):
        path = []
        while current in came_from:
            path.append(current)
            current = came_from[current]
        path.append(current)
        return path[::-1]

    def plot_path(self, path):
        fig = self.canvas.figure
        ax = fig.gca()
        for line in ax.lines:
            line.remove()
        x_vals = [x for x, y in path]
        y_vals = [y for x, y in path]
        ax.plot(y_vals, x_vals, color='blue', linewidth=2, label='Refined Path')
        ax.legend()
        self.canvas.draw()
        plt.savefig("Path_Plot.png")
        self.log("Saved path plot as Path_Plot.png")

    def plot_zoomed_path(self, path):
        xs = [x for x, y in path]
        ys = [y for x, y in path]
        margin = 20
        xmin, xmax = int(min(xs)) - margin, int(max(xs)) + margin
        ymin, ymax = int(min(ys)) - margin, int(max(ys)) + margin

        fig, ax = plt.subplots(figsize=(8, 6))
        ax.imshow(self.valid_mask, cmap='Greens')
        ax.plot(ys, xs, color='blue', linewidth=2)
        ax.set_xlim(ymin, ymax)
        ax.set_ylim(xmax, xmin)
        ax.set_title("Zoomed-In Path View")
        plt.savefig("Zoomed_Path.png")
        plt.close()
        self.log("Saved zoomed path as Zoomed_Path.png")

    def plot_visited_nodes(self):
        fig, ax = plt.subplots(figsize=(10, 8))
        ax.imshow(self.valid_mask, cmap='Greens')
        vx = [p[0] for p in self.visited_nodes]
        vy = [p[1] for p in self.visited_nodes]
        ax.scatter(vy, vx, color='red', s=1, label='Visited')
        ax.set_title("Visited Nodes During A* Search")
        ax.legend(loc="upper right")
        plt.savefig("Visited_Nodes.png")
        plt.close()
        self.log("Saved visited nodes map as Visited_Nodes.png")

    def plot_elevation_profile(self, path):
        elevations = [self.dem_data[int(x), int(y)] for x, y in path]
        plt.figure()
        plt.plot(range(len(elevations)), elevations, marker='o', linestyle='-')
        plt.xlabel("Step")
        plt.ylabel("Elevation (m)")
        plt.title("Elevation Profile Along Path")
        plt.savefig("elevation_profile.png")
        plt.close()

    def export_path_csv(self, path):
        rows = []
        for i, (x, y) in enumerate(path):
            lon, lat = rasterio.transform.xy(self.transform, int(x), int(y))
            elevation = self.dem_data[int(x), int(y)]
            rows.append([i, lat, lon, elevation])
        df = pd.DataFrame(rows, columns=["Step", "Latitude", "Longitude", "Elevation"])
        df.to_csv("path_coordinates.csv", index=False)
        self.log("Path coordinates exported to path_coordinates.csv")

    def save_graphs(self):
        self.canvas.figure.savefig("dem_path.png")
        self.log("Graph saved as dem_path.png")

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = DEMPathPlanner()
    window.show()
    sys.exit(app.exec_())
