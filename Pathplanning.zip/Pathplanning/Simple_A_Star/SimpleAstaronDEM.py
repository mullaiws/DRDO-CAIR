import sys
import numpy as np
import rasterio
import heapq
import matplotlib.pyplot as plt
from PyQt5.QtWidgets import QApplication, QMainWindow, QPushButton, QFileDialog, QVBoxLayout, QWidget, QInputDialog
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas, NavigationToolbar2QT as NavigationToolbar
import pandas as pd

class DEMPathPlanner(QMainWindow):
    def __init__(self):
        super().__init__()
        self.initUI()
        self.dem_data = None
        self.transform = None
        self.start = (72, 163)
        self.goal = (167, 120)
        self.go_area = None

    def initUI(self):
        self.setWindowTitle("DEM Path Planner")
        self.setGeometry(100, 100, 800, 600)

        self.canvas = FigureCanvas(plt.figure())
        self.toolbar = NavigationToolbar(self.canvas, self)
        #self.canvas.mpl_connect("button_press_event", self.mouse_click_event)

        self.btn_load = QPushButton("Load DEM", self)
        self.btn_load.clicked.connect(self.load_dem)

        self.btn_compute = QPushButton("Compute Path", self)
        self.btn_compute.clicked.connect(self.compute_path)
        

        layout = QVBoxLayout()
        layout.addWidget(self.toolbar)
        layout.addWidget(self.canvas)
        layout.addWidget(self.btn_load)
        layout.addWidget(self.btn_compute)

        container = QWidget()
        container.setLayout(layout)
        self.setCentralWidget(container)

    def load_dem(self):
        options = QFileDialog.Options()
        file_name, _ = QFileDialog.getOpenFileName(self, "Open DEM File", "", "GeoTIFF Files (*.tif);;All Files (*)", options=options)

        if file_name:
            with rasterio.open(file_name) as src:
                self.dem_data = src.read(1)
                self.transform = src.transform

            # Temporarily disable elevation filtering — treat entire DEM as valid
            self.go_area = np.ones_like(self.dem_data, dtype=bool)
            print("Elevation filtering disabled: using entire DEM as GO area.")

            self.plot_dem()

    def plot_dem(self):
        plt.clf()
        ax = self.canvas.figure.add_subplot(111)
        ax.imshow(self.dem_data, cmap='terrain')
        ax.set_title("DEM Map - Simple A Star Path Planner")
        ax.set_xlabel("Column Index")
        ax.set_ylabel("Row Index")
        ax.grid(True, which='both', color='gray', linestyle='--', linewidth=0.5)

        if self.go_area is not None:
            ax.imshow(self.go_area, cmap='coolwarm', alpha=0.3)

        if self.start:
            ax.plot(self.start[1], self.start[0], marker='o', color='green', markersize=8, label='Start')
        if self.goal:
            ax.plot(self.goal[1], self.goal[0], marker='o', color='red', markersize=8, label='Goal')

        if self.start or self.goal:
            ax.legend()

        self.canvas.draw()


    def mouse_click_event(self, event):
        if event.xdata is None or event.ydata is None:
            return

        row, col = int(event.ydata), int(event.xdata)

        if self.go_area is not None and not self.go_area[row, col]:
            print("Selected point is not in GO area! Choose another location.")
            return

        if self.start is None:
            self.start = (row, col)
            print(f"Start set at: {self.start}")
        elif self.goal is None:
            self.goal = (row, col)
            print(f"Goal set at: {self.goal}")

        self.plot_dem()

    def compute_path(self):
        if self.dem_data is None or self.start is None or self.goal is None:
            print("Load DEM, and select start/goal points first!")
            return

        path = self.a_star()
        if path:
            self.plot_path(path)
            self.plot_elevation_profile(path)
            self.save_graphs()
        else:
            print("No valid path found!")

    def a_star(self):
        rows, cols = self.dem_data.shape
        start_x, start_y = self.start
        goal_x, goal_y = self.goal

        open_set = [(0, start_x, start_y)]
        heapq.heapify(open_set)
        came_from = {}
        g_score = np.full((rows, cols), np.inf, dtype=float)
        g_score[start_x, start_y] = 0

        directions = [(-1, 0), (1, 0), (0, -1), (0, 1),
                      (-1, -1), (-1, 1), (1, -1), (1, 1)]

        def heuristic(a, b):
            (ax, ay), (bx, by) = a, b
            return np.hypot(ax - bx, ay - by)

        while open_set:
            _, x, y = heapq.heappop(open_set)

            if (x, y) == (goal_x, goal_y):
                return self.reconstruct_path(came_from, (goal_x, goal_y))

            for dx, dy in directions:
                nx, ny = x + dx, y + dy

                if 0 <= nx < rows and 0 <= ny < cols and self.go_area[nx, ny]:
                    step_cost = np.hypot(dx, dy)
                    tentative_g = g_score[x, y] + step_cost

                    if tentative_g < g_score[nx, ny]:
                        came_from[(nx, ny)] = (x, y)
                        g_score[nx, ny] = tentative_g
                        f_score = tentative_g + heuristic((nx, ny), (goal_x, goal_y))
                        heapq.heappush(open_set, (f_score, nx, ny))

        return None

    def reconstruct_path(self, came_from, current):
        path = []
        while current in came_from:
            path.append(current)
            current = came_from[current]
        path.append(current)
        return path[::-1]

    def plot_path(self, path):
        for x, y in path:
            plt.plot(y, x, marker='.', color='blue', markersize=2)
        self.canvas.draw()
        plt.savefig("Path_Plot.png")
        print("Saved path plot as Path_Plot.png")

    def plot_elevation_profile(self, path):
        elevations = [self.dem_data[x, y] for x, y in path]
        plt.figure()
        plt.plot(range(len(elevations)), elevations, marker='o', linestyle='-')
        plt.xlabel("Step")
        plt.ylabel("Elevation (m)")
        plt.title("Elevation Profile Along Path")
        plt.savefig("elevation_profile.png")
        plt.show()

    def save_graphs(self):
        self.canvas.figure.savefig("dem_path.png")
        print("Graph saved as dem_path.png")

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = DEMPathPlanner()
    window.show()
    sys.exit(app.exec_())