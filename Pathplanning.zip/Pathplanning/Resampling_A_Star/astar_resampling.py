import sys
import numpy as np
import rasterio
import heapq
import matplotlib.pyplot as plt
from PyQt5.QtWidgets import QApplication, QMainWindow, QPushButton, QFileDialog, QVBoxLayout, QWidget, QInputDialog
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas, NavigationToolbar2QT as NavigationToolbar
import pandas as pd
from shapely.geometry import LineString

class DEMPathPlanner(QMainWindow):
    def __init__(self):
        super().__init__()
        self.initUI()
        self.dem_data = None
        self.transform = None
        self.start = (72, 163)
        self.goal = (167, 120)
        self.go_area = None

    def initUI(self):
        self.setWindowTitle("DEM Path Planner with Resampling")
        self.setGeometry(100, 100, 800, 600)

        self.canvas = FigureCanvas(plt.figure())
        self.toolbar = NavigationToolbar(self.canvas, self)
        #self.canvas.mpl_connect("button_press_event", self.mouse_click_event)

        self.btn_load = QPushButton("Load DEM", self)
        self.btn_load.clicked.connect(self.load_dem)

        self.btn_compute = QPushButton("Compute Path", self)
        self.btn_compute.clicked.connect(self.compute_path)

        layout = QVBoxLayout()
        layout.addWidget(self.toolbar)
        layout.addWidget(self.canvas)
        layout.addWidget(self.btn_load)
        layout.addWidget(self.btn_compute)

        container = QWidget()
        container.setLayout(layout)
        self.setCentralWidget(container)

    def load_dem(self):
        options = QFileDialog.Options()
        file_name, _ = QFileDialog.getOpenFileName(self, "Open DEM File", "", "GeoTIFF Files (*.tif);;All Files (*)", options=options)

        if file_name:
            with rasterio.open(file_name) as src:
                self.dem_data = src.read(1)
                self.transform = src.transform

            self.go_area = np.ones_like(self.dem_data, dtype=bool)
            print("Elevation filtering disabled: using entire DEM as GO area.")

            self.plot_dem()

    def plot_dem(self):
        plt.clf()
        ax = self.canvas.figure.add_subplot(111)
        ax.imshow(self.dem_data, cmap='terrain')
        ax.set_title("DEM Map - A Star Path Planner with Pixel Resampling")
        ax.set_xlabel("Column Index")
        ax.set_ylabel("Row Index")
        ax.grid(True, which='both', color='gray', linestyle='--', linewidth=0.5)

        if self.go_area is not None:
            ax.imshow(self.go_area, cmap='coolwarm', alpha=0.3)

        if self.start:
            ax.plot(self.start[1], self.start[0], marker='o', color='green', markersize=8, label='Start')
        if self.goal:
            ax.plot(self.goal[1], self.goal[0], marker='o', color='red', markersize=8, label='Goal')

        if self.start or self.goal:
            ax.legend()

        self.canvas.draw()

    def mouse_click_event(self, event):
        if event.xdata is None or event.ydata is None:
            return

        row, col = int(event.ydata), int(event.xdata)

        if self.go_area is not None and not self.go_area[row, col]:
            print("Selected point is not in GO area! Choose another location.")
            return

        if self.start is None:
            self.start = (row, col)
            print(f"Start set at: {self.start}")
        elif self.goal is None:
            self.goal = (row, col)
            print(f"Goal set at: {self.goal}")

        self.plot_dem()

    def compute_path(self):
        if self.dem_data is None or self.start is None or self.goal is None:
            print("Load DEM, and select start/goal points first!")
            return

        path = self.a_star_subpixel()
        if path:
            self.plot_path(path)
            self.plot_elevation_profile(path)
            self.save_graphs()
        else:
            print("No valid path found!")

    def a_star_subpixel(self, substeps=4):
        rows, cols = self.dem_data.shape
        start = (self.start[0] + 0.5, self.start[1] + 0.5)
        goal = (self.goal[0] + 0.5, self.goal[1] + 0.5)

        open_set = [(0, start)]
        heapq.heapify(open_set)
        came_from = {}
        g_score = {start: 0}

        directions = [(dx / substeps, dy / substeps)
                      for dx in range(-substeps, substeps + 1)
                      for dy in range(-substeps, substeps + 1)
                      if not (dx == 0 and dy == 0)]

        def heuristic(a, b):
            return np.hypot(a[0] - b[0], a[1] - b[1])

        visited = set()

        while open_set:
            _, current = heapq.heappop(open_set)
            if (int(current[0]), int(current[1])) == (int(goal[0]), int(goal[1])):
                return self.reconstruct_path(came_from, current)

            if current in visited:
                continue
            visited.add(current)

            for dx, dy in directions:
                neighbor = (current[0] + dx, current[1] + dy)
                r, c = int(neighbor[0]), int(neighbor[1])
                if 0 <= r < rows and 0 <= c < cols and self.go_area[r, c]:
                    tentative_g = g_score[current] + np.hypot(dx, dy)
                    if neighbor not in g_score or tentative_g < g_score[neighbor]:
                        came_from[neighbor] = current
                        g_score[neighbor] = tentative_g
                        f_score = tentative_g + heuristic(neighbor, goal)
                        heapq.heappush(open_set, (f_score, neighbor))

        return None

    def reconstruct_path(self, came_from, current):
        path = []
        while current in came_from:
            path.append(current)
            current = came_from[current]
        path.append(current)
        return path[::-1]

    def plot_path(self, path):
        self.plot_dem()
        x_vals = [x for x, y in path]
        y_vals = [y for x, y in path]
        ax = self.canvas.figure.axes[0]
        ax.plot(y_vals, x_vals, color='blue', linewidth=2, label='Refined Path')
        ax.legend()
        self.canvas.draw()
        plt.savefig("Path_Plot.png")
        print("Saved path plot as Path_Plot.png")

    def plot_elevation_profile(self, path):
        elevations = [self.dem_data[int(x), int(y)] for x, y in path]
        plt.figure()
        plt.plot(range(len(elevations)), elevations, marker='o', linestyle='-')
        plt.xlabel("Step")
        plt.ylabel("Elevation (m)")
        plt.title("Elevation Profile Along Path")
        plt.savefig("elevation_profile.png")
        plt.show()

    def save_graphs(self):
        self.canvas.figure.savefig("dem_path.png")
        print("Graph saved as dem_path.png")

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = DEMPathPlanner()
    window.show()
    sys.exit(app.exec_())
